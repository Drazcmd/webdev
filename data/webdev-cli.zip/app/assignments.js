// Service endpoints for homework submission

const moment = require('moment')
const myGit = require('./git')
const { getGitCommit, Assignment, AssignmentGrades } = myGit

exports.loadAssignments = loadAssignments
exports.getTerm = () => `${planning.class.year}${planning.class.term}`

//******************************************************************//

let planning, assignments
function loadAssignments() {

    function processAssignments() {
        assignments = [
            ...planning.sessions.filter((e) => {
                return e.day
            }).map((e) => {
                return { key: `inclass-${e.day}`, day: e.day, dueTime: getDueTime(e.day, e.offset), dueDate: getDueDate(e.day, e.offset), name: e.topic, type: 'inclass' }
            }),
            ...planning.assignments.filter((e) => {
                return e.name.indexOf('COMP531') < 0 || e.id === 'paper'
            }).map((e, i) => {
                const ii = e.id === 'paper' ? `-${e.id}` : i+1
                const type = e.id === 'paper' ? 'inclass' : 'hw'
                return { key: `hw${ii}`, day: e.due, dueTime: getDueTime(e.day, e.offset), dueDate: getDueDate(e.due, 0), name: e.name, type: type }
            })
        ]
        assignments.sort((a, b) => {
            if (a.day < b.day) return -1
            if (a.day > b.day) return +1
            if (a.type === 'inclass') return -1
            if (b.type === 'inclass') return +1
            return 0
        })
    }

    return new Promise((resolve, reject) => {
        planning = require('./planning.json')
        processAssignments()
        resolve(assignments)
    })
}

function getDueDate(sessionDay, offset = 0) {
   return getDueTime(sessionDay, offset)
        .format("ddd MM/DD")
}

function getDueTime(sessionDay, offset = 0) {
    var week = Math.floor((sessionDay + offset - 1) / 2);
    var dow = (sessionDay + offset - 1) - 2 * week;
    return moment(planning.class.firstDay)
        .add(week, 'weeks').add(dow * 2, 'days')
}

