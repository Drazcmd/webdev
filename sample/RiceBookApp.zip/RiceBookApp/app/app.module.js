(function() {
'use strict'

angular.module('riceBookApp', [])	


})();
