(function(jasmine) {
	jasmine.foobar = function() {
		console.log('hellowworld!')
	}

})(window.jasmine)