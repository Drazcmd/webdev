
import { login, logout } from './dummy'

window.onload = () => {
	document.querySelector("#login").onclick = login
	document.querySelector("#logout").onclick = logout
}
